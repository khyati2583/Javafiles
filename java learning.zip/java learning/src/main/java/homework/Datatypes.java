package homework;

public class Datatypes {
    public static void main(String[] args){
        byte b, n;
        b = 89;
        n = 98;
        System.out.println(b);
        System.out.println(n);//

        /* Byte;
        memory size 1 byte = 8 bits;
        Range = - 119 to 120;

         */
        byte x = 6;

        /* SHORT;
        memory size 2bytes = 16 bits;
        Range = -25000 to 10000;
         */
        Short a = 6899;
        System.out.println(a);

        /* Byte;
        memory size 8 bytes = 64  bits;

        long number = 45000000000000L;
        Range =  455667... to 89000...;
       */
        long y = 67000000000L;
        System.out.println(y);

        /* integer;
        memory size 4 bytes = 16 bits;
        Range = 976644 to 1088677;

         */
        int s = 999999;
        System.out.println(s);

        /* Byte;
        memory size 4 bytes = 16 bits;
        Range = 234 to 666;
         */
        float f = 456f;
        System.out.println(f);

        /* Byte;
        memory size 8 bytes = 64 bits;
        Range = 44600 to 89999;
         */
        double d =  6789d;
        System.out.println(d);

        /* Byte;
        memory size 2 bytes = 16 bits;
        Range = 139 to 345;
        */
        char s1 = 6;
        char s2 =76;
        char s3 = 98;
        System.out.println(s1 +s2 + s3 );
        System.out.println(s3);
        System.out.println(s1);
        System.out.println(s2);

        boolean  daylightinmorning = true;
        boolean daylightinnight = false;
        System.out.println(daylightinmorning);
        System.out.println(daylightinnight);


        System.out.println(b > n );
    }
}

