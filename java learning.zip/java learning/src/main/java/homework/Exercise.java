public class Exercise {
    public static void main(String[] args) {
        //  int a = 19;
        if (19 >= 18) ;
        {
            System.out.println("You are eligible to vote");
        }
        // int number = -1;
        if (-1 < 0) ;
        {
            System.out.println("-1 is a negative number");
        }
        int number = 0;
        // check if the number is positive or negative
        if (0 >= -1) {
            System.out.println("0 is a positive number");
        } else {
            System.out.println("0 is a negative number");
        }
        int x = 600;
        // check if the number is divided by 2 or not
        if (600 % 2 == 0) {
            System.out.println("even number");
        } else {
            System.out.println("odd number");
        }
        int a = 40;
        int b = 400;
        System.out.println(b % a);
    }
        }
