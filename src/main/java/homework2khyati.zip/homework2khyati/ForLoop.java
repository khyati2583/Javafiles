package homework2khyati;

public class ForLoop {
    public static void main(String[] args) {

        for (int k = 0; k < 20; k++) {
            System.out.println(k);
        }




        // nested loop

            for (int l=1;l<=5;l++)
                for (int n=1; n<=5;n++){
                    System.out.println(l+""+n);
                }

        }
    }

