package homework2khyati;

public class DowhileOddEven {
    public static void main(String[] args) {
        int y = 7;
        System.out.println("odd number");
        do {
            System.out.println(y + "");
            y = y + 2;
        } while (y<=40);

        int d= 12;
        System.out.println("Even number");
        do {
            System.out.println(d + "");
            d = d + 2;
        }while (d<=60);
        }


        }



