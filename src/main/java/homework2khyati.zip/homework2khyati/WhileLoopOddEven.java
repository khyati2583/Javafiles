package homework2khyati;

public class WhileLoopOddEven {
    public static void main(String[] args) {
        int i =5;
        System.out.println("odd number");
        while (i<=50){
            System.out.println(i+"");
            i= i+2;
        }

        System.out.println("even number");
        int x= 2;
        while (x<=50){
            System.out.println(x+"");
            x= x+2;

        }
    }

}
