package homework2khyati;

public class WhileLoopTablesof9 {
    public static void main(String[] args) {
        int i = 9;
        while(i<=90){
            System.out.println(i+"");
            i=i+9;
    }
        }
    }


