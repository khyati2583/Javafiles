package homework2khyati;

public class HomeTableof8DoWhile {
    public static void main(String[] args) {
        int y=8;
        do {
            System.out.println(y+"");
            y=y+8;
        }while (y<=80);
        }
    }

