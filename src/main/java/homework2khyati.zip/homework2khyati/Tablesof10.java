package homework2khyati;

public class Tablesof10 {
    public static void main(String[] args) {
        int x = 10;
        x = 20;
        x= 30;
        x= 40;
        x = 50;
        x = 60;
        x = 70;
        x = 80;
        x = 90;
        x = 100;

        int y[] = new int[10];

        y[0]=10;
        y[1]=20;
        y[2]=30;
        y[3]=40;
        y[4]=50;
        y[5]=60;
        y[6]=70;
        y[7]=80;
        y[8]=90;
        y[9]=100;

        for(int i=0;i<y.length;i++){
            System.out.println(y[i]);
        }
    }
}



